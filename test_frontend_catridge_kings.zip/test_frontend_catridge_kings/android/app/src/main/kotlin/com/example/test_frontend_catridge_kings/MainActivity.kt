package com.example.test_frontend_catridge_kings

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
